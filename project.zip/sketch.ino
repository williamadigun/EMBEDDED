 #include <ESP32Servo.h> 

// Hardware Pin Assignments
#define LDR_MODULE_1 22   
#define LDR_MODULE_2 34   
#define BUZZER_PIN 14    
#define SERVO_PIN 15     

Servo perimeterLock;

unsigned long zone1Time = 0;
unsigned long zone2Time = 0;
const unsigned long TIMEOUT_WINDOW = 3000; 

// Simulation Control Variables
int simulationStage = 0;
unsigned long lastSimTime = 0;

void setup() {
  Serial.begin(115200);
  while (!Serial) { ; }
  delay(500);

  // Set pin modes for software injection testing
  pinMode(LDR_MODULE_1, OUTPUT);
  pinMode(LDR_MODULE_2, OUTPUT); 
  pinMode(BUZZER_PIN, OUTPUT);
  
  digitalWrite(LDR_MODULE_1, LOW);
  digitalWrite(LDR_MODULE_2, LOW);

  // Allow the servo library to allocate a standard ESP32 timer channel
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  
  perimeterLock.setPeriodHertz(50); // Standard 50Hz servo refresh rate
  perimeterLock.attach(SERVO_PIN, 500, 2400); // Minimum and maximum pulse widths
  perimeterLock.write(0); // Explicitly lock to starting point

  Serial.println("\n=============================================");
  Serial.println("   ESP32 ACTUATOR-OPTIMIZED SIMULATOR RUNNING ");
  Serial.println("=============================================");
}

void loop() {
  unsigned long currentTime = millis();

  // --- AUTOMATED BEHAVIOR SIMULATOR INTERFACE ---
  if (currentTime - lastSimTime > 12000) {
    lastSimTime = currentTime;
    simulationStage++;
    
    if (simulationStage == 1) {
      Serial.println("\n🏃 [SIMULATION]: Testing INTRUDER ENTRY Sequence...");
      digitalWrite(LDR_MODULE_1, HIGH); 
      delay(400);
      digitalWrite(LDR_MODULE_2, HIGH); 
      delay(200);
      digitalWrite(LDR_MODULE_1, LOW);  
      delay(400);
      digitalWrite(LDR_MODULE_2, LOW);  
    } 
    else if (simulationStage == 2) {
      Serial.println("\n🚶 [SIMULATION]: Testing AUTHORIZED EXIT Sequence...");
      digitalWrite(LDR_MODULE_2, HIGH); 
      delay(400);
      digitalWrite(LDR_MODULE_1, HIGH); 
      delay(200);
      digitalWrite(LDR_MODULE_2, LOW);  
      delay(400);
      digitalWrite(LDR_MODULE_1, LOW);  
    } 
    else if (simulationStage == 3) {
      Serial.println("\n⚡ [SIMULATION]: Testing HARDWARE TAMPER/BLOCK Sequence...");
      digitalWrite(LDR_MODULE_1, HIGH); 
    }
    else {
      Serial.println("\n🔄 [SIMULATION]: Resetting tester loop back to standby.");
      digitalWrite(LDR_MODULE_1, LOW);
      digitalWrite(LDR_MODULE_2, LOW);
      simulationStage = 0; 
    }
  }

  // --- CORE SECURITY EVALUATION ENGINE ---
  bool zone1Breached = (digitalRead(LDR_MODULE_1) == HIGH);
  bool zone2Breached = (digitalRead(LDR_MODULE_2) == HIGH);

  if (zone1Breached && zone1Time == 0) {
    zone1Time = millis();
    Serial.println(" -> Hardware Log: Pin 22 Tripped.");
  }
  if (zone2Breached && zone2Time == 0) {
    zone2Time = millis();
    Serial.println(" -> Hardware Log: Pin 34 Tripped.");
  }

  // Evaluate Threat Profiles
  if (zone1Time > 0 && zone2Time > 0 && zone1Time < zone2Time) {
    if ((zone2Time - zone1Time) < TIMEOUT_WINDOW) {
      Serial.println("🚨 RESULTS: Intrusion Confirmed. Actuating Physical Grid...");
      triggerLockdown();
    }
    resetSystemState();
  }
  else if (zone1Time > 0 && zone2Time > 0 && zone2Time < zone1Time) {
    if ((zone1Time - zone2Time) < TIMEOUT_WINDOW) {
      Serial.println("✅ RESULTS: Authorized Exit Confirmed. Access Granted.");
      delay(1000); 
    }
    resetSystemState();
  }
  else if ((zone1Time > 0 && (millis() - zone1Time) > TIMEOUT_WINDOW) || 
           (zone2Time > 0 && (millis() - zone2Time) > TIMEOUT_WINDOW)) {
    Serial.println("⚠️ RESULTS: Timeout Exceeded. Single sensor blocked or broken.");
    resetSystemState();
  }

  delay(50); 
}

void triggerLockdown() {
  Serial.println("⚙️ Moving Servo to 90 degrees...");
  perimeterLock.write(90); // Rotate physical lock
  
  // Use active frequency tones instead of simple digital writes
  for (int i = 0; i < 3; i++) {
    tone(BUZZER_PIN, 880); delay(150); // Sound a crisp note
    noTone(BUZZER_PIN);    delay(100);
    tone(BUZZER_PIN, 1200); delay(150); // Alternating high tone
    noTone(BUZZER_PIN);    delay(100);
  }
  
  delay(1500); // Hold security state
  
  Serial.println("⚙️ Returning Servo to 0 degrees...");
  perimeterLock.write(0); // Reset lock position
}

void resetSystemState() {
  zone1Time = 0;
  zone2Time = 0;
}